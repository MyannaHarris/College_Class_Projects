READ_ME

To run the Othello game, run the Othello python file.

To run that file…

python othello.py #
# = 1 for WB start
# = 2 for BW start